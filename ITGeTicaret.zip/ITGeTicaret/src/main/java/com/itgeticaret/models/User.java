package com.itgeticaret.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String password;
    private String email;

    private String activationCode;

    @ManyToMany(fetch = FetchType.EAGER)
    private List<Role> roles = new ArrayList<>();

    @OneToMany(mappedBy = "user",cascade = CascadeType.ALL)
    @JsonIgnore
    private List<PurchaseOrder> purchaseOrders = new ArrayList<>();

    private boolean active;


    public User(long id, String password, String email, List<PurchaseOrder> purchaseOrders) {
        this.id = id;
        this.password = password;
        this.email = email;
        this.purchaseOrders = purchaseOrders;
    }
}
