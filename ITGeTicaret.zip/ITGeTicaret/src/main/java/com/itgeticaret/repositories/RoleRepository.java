package com.itgeticaret.repositories;

public interface RoleRepository {
}
