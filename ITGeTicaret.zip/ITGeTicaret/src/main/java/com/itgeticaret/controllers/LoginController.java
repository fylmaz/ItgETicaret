package com.itgeticaret.controllers;

import com.itgeticaret.models.User;
import com.itgeticaret.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private UserService userService;

    @GetMapping
    public String showLoginForm(Model model) {
        model.addAttribute("user", new User());
        return "login";
    }
    @Autowired
    private AuthenticationManager authenticationManager;

    @PostMapping
    public ResponseEntity<Object> login(@RequestParam("email") String email, @RequestParam("password") String password) {
        try {
            UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(email, password);
            Authentication authentication = authenticationManager.authenticate(authenticationToken);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            return ResponseEntity.ok("Login successful");
        } catch (AuthenticationException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }

   /* @PostMapping("/login")
    public String login(@ModelAttribute("user") User user, Model model) {

        User existingUser = userService.getUserByEmail(user.getEmail());

        if (existingUser == null) {
            model.addAttribute("error", "Kullanıcı bulunamadı.");
            return "login";
        }

        if (!existingUser.isActive()) {
            model.addAttribute("error", "Hesabınız aktif değil. Lütfen hesabınızı aktifleştirin.");
            return "login";
        }

        if (!existingUser.getPassword().equals(user.getPassword())) {
            model.addAttribute("error", "Geçersiz şifre.");
            return "login";
        }

        // Başarılı giriş durumunda yönlendirme yapabilirsiniz
        return "redirect:/home";
    }*/
}

